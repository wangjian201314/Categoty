//
//  CategoryHeader.h
//  MTCommon
//
//  Created by 辛忠志 on 2018/11/30.
//  Copyright © 2018年 mastercom. All rights reserved.
//

#ifndef CategoryHeader_h
#define CategoryHeader_h

/**
 *   声明:为让所有分类都不需要分别导入头文件 创建CategoryHeader 管理全部分类.h文件！！！！！！！
 */

#pragma mark - UIFont

#import "UIFont+runTime.h"    /*label大小随屏宽变而改变*/

#pragma mark - UIAlertView

#import "UIAlertView+Block.h"   /*AlertView 二次封装*/

#pragma mark - UIWindow

#import "UIWindow+Hierarchy.h"     /*输出堆栈顶层 VC*/

#pragma mark - UILabel
#import "UILabel+FitSizeHeight.h"      /*label 各种算高*/
#import "UILabel+ChangeLineSpaceAndWordSpace.h"  /*label 行间距&字间距*/
#import "BaseLabel.h"           /* 重写drawTextInRect */

#pragma mark - UIColor
#import "UIColor+Gradient.h"   /* 渐变色*/
#import "UIColor+HEX.h"
#import "UIColor+Random.h"       /*随机色*/
#import "UIColor+Web.h"             /*web页面的颜色*/
#import "UIColor+Modify.h"

#pragma mark - UIDevice
#import "UIDevice+MTHardware.h"
#import "UIDevice+MTPasscodeStatus.h"

#pragma mark - UITextField
#import "UITextField+Blocks.h"       /*将UITextField 的所有代理 用block的形式展示*/
#import "UITextField+History.h"         /*输入 UITextField 历史输入文字*/
#import "UITextField+MTInputLimit.h"
#import "UITextField+Select.h"          /*选中一定区间内UITextField的值*/
     


#pragma mark - UIView
#import "UIView+Debug.h"
#import "UIView+Nib.h"





#endif /* CategoryHeader_h */
