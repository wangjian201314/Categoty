//
//  NSException+Trace.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 14/12/30.
//  Copyright (c) 2014年 X了个J. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSException (Trace)
- (NSArray *)backtrace;
@end
