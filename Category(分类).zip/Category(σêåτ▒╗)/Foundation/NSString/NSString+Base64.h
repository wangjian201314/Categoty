//
//  NSString+Base64.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/2/8.
//  Copyright (c) 2015年 X了个J. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Base64)
/*
 time(时间): 2015 - 2 - 8
 
 description(描述):  NSString和UTF-8间的转换

 ... ...
 */
+ (NSString *)stringWithBase64EncodedString:(NSString *)string;
- (NSString *)base64EncodedStringWithWrapWidth:(NSUInteger)wrapWidth;
- (NSString *)base64EncodedString;
- (NSString *)base64DecodedString;
- (NSData *)base64DecodedData;
@end
