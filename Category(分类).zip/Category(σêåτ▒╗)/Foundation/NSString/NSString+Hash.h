//
//  NSString+Hash.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 14/12/15.
//  Copyright (c) 2014年 X了个J. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface NSString (Hash)
@property (readonly) NSString *md5String;
@property (readonly) NSString *sha1String;
@property (readonly) NSString *sha256String;
@property (readonly) NSString *sha512String;

- (NSString *)hmacMD5StringWithKey:(NSString *)key;
- (NSString *)hmacSHA1StringWithKey:(NSString *)key;
- (NSString *)hmacSHA256StringWithKey:(NSString *)key;
- (NSString *)hmacSHA512StringWithKey:(NSString *)key;
@end
