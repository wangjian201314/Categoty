//
//  NSString+Date.m
//  QiJingVR
//
//  Created by 辛忠志 on 16/6/25.
//  Copyright © 2016年 X了个J. All rights reserved.
//

#import "NSString+Date.h"

@implementation NSString (Date)

+ (NSString *)intervalFromLastDate:(NSString *)dateString1 toTheDate:(NSString *)dateString2
{
    NSArray *timeArray1=[dateString1 componentsSeparatedByString:@"."];
    dateString1=[timeArray1 objectAtIndex:0];
    
    
    NSArray *timeArray2=[dateString2 componentsSeparatedByString:@"."];
    dateString2=[timeArray2 objectAtIndex:0];
    
    NSDateFormatter *date=[[NSDateFormatter alloc] init];
    [date setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    
    NSDate *d1=[date dateFromString:dateString1];
    
    NSTimeInterval late1=[d1 timeIntervalSince1970]*1;
    
    
    
    NSDate *d2=[date dateFromString:dateString2];
    
    NSTimeInterval late2=[d2 timeIntervalSince1970]*1;
    
    
    
    NSTimeInterval cha=late2-late1;
    NSString *timeString=@"";
    NSString *house=@"";
    NSString *min=@"";
    NSString *sen=@"";
    
    sen = [NSString stringWithFormat:@"%d", (int)cha%60];
    // min = [min substringToIndex:min.length-7];
    // 秒
    sen=[NSString stringWithFormat:@"%@", sen];
    
    
    
    min = [NSString stringWithFormat:@"%d", (int)cha/60%60];
    // min = [min substringToIndex:min.length-7];
    // 分
    min=[NSString stringWithFormat:@"%@", min];
    
    
    // 小时
    house = [NSString stringWithFormat:@"%d", (int)cha/3600];
    // house = [house substringToIndex:house.length-7];
    house=[NSString stringWithFormat:@"%@", house];
    
    
    timeString=[NSString stringWithFormat:@"%@:%@:%@",house,min,sen];
    
    
    return timeString;
}

+ (NSString *)conversionTimeStamp:(NSString *)theTimeStamp {
    
    NSTimeInterval time=[theTimeStamp doubleValue];// +28800 因为时差问题要加8小时 == 28800 sec (若需要)
    
    NSDate *detaildate=[NSDate dateWithTimeIntervalSince1970:time];
    
    NSLog(@"date:%@",[detaildate description]);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString *currentDateStr = [dateFormatter stringFromDate: detaildate];
    
    return currentDateStr;
}
+ (NSString *)conversionTimeStampAddOneMonth:(NSString *)theTimeStamp addMonthCount:(int)monthCount{
    
    
    /*首先知道当前月份有多少天*/
    
    NSString * timeData = [self getCurrentDate];
    NSLog(@"%@",timeData);
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSRange range = [calendar rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:[NSDate date]];
    
    NSUInteger numberOfDaysInMonth = range.length;
    
    NSLog(@"%lu", (unsigned long)numberOfDaysInMonth);
    
    
    /*获取当前是几号 然后用当月的天数-今天是几号 就是本月还剩余多少天*/
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd"];
    NSString *dayTime = [formatter stringFromDate:[NSDate date]];
    NSLog(@"%@",dayTime);
    /*本月剩余多少天*/
    int remainingDayTime = (unsigned long)numberOfDaysInMonth - [dayTime intValue];
    
    /*本月剩余多少天 + 1 就一定能到下个月了。*/
    NSTimeInterval time=[theTimeStamp doubleValue]+monthCount*24*(remainingDayTime+1)*3600;// +28800 因为时差问题要加8小时 == 28800 sec (若需要) /*我这里加上*/
    
    NSDate *detaildate=[NSDate dateWithTimeIntervalSince1970:time];
    
    NSLog(@"date:%@",[detaildate description]);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString *currentDateStr = [dateFormatter stringFromDate: detaildate];
    
    return currentDateStr;
}
+ (NSString *)getCurrentDate {
    return [self conversionTimeStamp:[NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]]];
}

+ (NSString *)timeFormatted:(int)totalSeconds
{
    
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
    int hours = totalSeconds / 3600;
    
    return [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];
}
+ (NSString *)getcurrentTimetamp {
    NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a=[dat timeIntervalSince1970]*1000;
    NSString *timeString = [NSString stringWithFormat:@"%f", a];
    return timeString;
}
+ (NSString *)ConvertStrToTime:(NSString *)timeStr

{
    
    long long time=[timeStr longLongValue];
    
    NSDate *d = [[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    
    [formatter setDateFormat:@"yyyy-MM-dd"];
    
    NSString*timeString=[formatter stringFromDate:d];
    
    return timeString;
    
}
+ (NSString *)ChineseConvertStrToTime:(NSString *)timeStr

{
    
    long long time=[timeStr longLongValue];
    
    NSDate *d = [[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    
    [formatter setDateFormat:@"yyyy年MM月dd日前"];
    
    NSString*timeString=[formatter stringFromDate:d];
    
    return timeString;
    
}
+ (NSString *)ConvertStrToDetialTime:(NSString *)timeStr

{
    
    long long time=[timeStr longLongValue];
    
    NSDate *d = [[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    
    NSString*timeString=[formatter stringFromDate:d];
    
    return timeString;
    
}
/*获取当前时间并在此基础上加上若干月*/

+ (NSString *)getCurrentDateAddMonth:(int)addData{
    
    NSDate * date = [NSDate date];
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    //设置时间间隔（秒）（这个我是计算出来的，不知道有没有简便的方法 )
    NSTimeInterval time = (365 * 24 * 60 * 60)*addData/12;//一年的秒数
    //得到一年之前的当前时间（-：表示向前的时间间隔（即去年），如果没有，则表示向后的时间间隔（即明年））
    NSDate * lastYear = [date dateByAddingTimeInterval:+time];
    //转化为字符串
    NSString * startDate = [dateFormatter stringFromDate:lastYear];
    return startDate;
}
/*获取指定时间并在此基础上加上若干月*/
+ (NSString *)getAssignCurrentDateAddMonth:(int)addData timeData:(NSString *)data{
    NSLog(@"%@",data);
    
    
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate * date = [dateFormatter dateFromString:data];
    //设置时间间隔（秒）（这个我是计算出来的，不知道有没有简便的方法 )
    NSTimeInterval time = (365 * 24 * 60 * 60)*addData/12;//一年的秒数
    //得到一年之前的当前时间（-：表示向前的时间间隔（即去年），如果没有，则表示向后的时间间隔（即明年））
    NSDate * lastYear = [date dateByAddingTimeInterval:+time];
    //转化为字符串
    NSString * startDate = [dateFormatter stringFromDate:lastYear];
    return startDate;
}



+ (NSString *)getMonthBeginAndEndWith:(int)monthCount{
    
    /*
     addMonthCount 你要加的月数
     */
    NSString * timeStr = [self conversionTimeStampAddOneMonth:[NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]] addMonthCount:monthCount];
    
    NSDateFormatter *format=[[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *newDate=[format dateFromString:timeStr];
    double interval = 0;
    NSDate *beginDate = nil;
    NSDate *endDate = nil;
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    [calendar setFirstWeekday:2];//设定周一为周首日
    BOOL ok = [calendar rangeOfUnit:NSMonthCalendarUnit startDate:&beginDate interval:&interval forDate:newDate];
    //分别修改为 NSDayCalendarUnit NSWeekCalendarUnit NSYearCalendarUnit
    if (ok) {
        endDate = [beginDate dateByAddingTimeInterval:interval-1];
    }else {
        return @"";
    }
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *beginString = [myDateFormatter stringFromDate:beginDate];
    NSString *endString = [myDateFormatter stringFromDate:endDate];
    
    
    NSString *s = [NSString stringWithFormat:@"%@",beginString];
    return s;
}

/*时间转时间戳*/
+(NSInteger)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format{
    
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:format]; //(@"YYYY-MM-dd hh:mm:ss") ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    
    
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    
    [formatter setTimeZone:timeZone];
    
    
    
    NSDate* date = [formatter dateFromString:formatTime]; //------------将字符串按formatter转成nsdate
    
    //时间转时间戳的方法:
    
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    
    
    
    NSLog(@"将某个时间转化成 时间戳&&&&&&&timeSp:%ld",(long)timeSp); //时间戳的值
    
    
    
    return timeSp;
    
}
+(NSString *)getTimeString:(NSString *)dateType{
    NSDate *nowDate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    formatter.dateFormat = dateType;
    formatter.timeZone = [NSTimeZone systemTimeZone];
    NSString *nowTimeString = [formatter stringFromDate:nowDate];
    return nowTimeString;
}
+(NSString *)DateToString:(NSDate *)date dateFormatterType:(NSString *)dateFormatterType{
//    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    /*判断传入类型 ~ dateFormatterType 去展示不同字符串 默认为 yyyy-MM-dd HH:mm:ss*/
    if (!dateFormatterType) {
        dateFormatterType = @"yyyy-MM-dd HH:mm:ss";
    }
    // 2018-01-22 15:12:55
    else if ([dateFormatterType isEqualToString:@"yyyy-MM-dd HH:mm"]){
        [dateFormatter setDateFormat:dateFormatterType];
    }
    // 2018-01-22 15:12
    else if ([dateFormatterType isEqualToString:@"yyyy-MM-dd HH:mm"]){
        [dateFormatter setDateFormat:dateFormatterType];
    }
    // 2018-01-22 15
    else if ([dateFormatterType isEqualToString:@"yyyy-MM-dd HH"]){
        [dateFormatter setDateFormat:dateFormatterType];
    }
    // 2018-01-22
    else if ([dateFormatterType isEqualToString:@"yyyy-MM-dd"]){
        [dateFormatter setDateFormat:dateFormatterType];
    }
    // 2018-01-22
    else if ([dateFormatterType isEqualToString:@"HH:mm:ss"]){
        [dateFormatter setDateFormat:dateFormatterType];
    }
    // 2018-01-22 15:12:55
    else{
        [dateFormatter setDateFormat:dateFormatterType];
    }
    
    NSString *strDate = [dateFormatter stringFromDate:date];
    
    return strDate;
}

#pragma mark - 新版接口(推荐)

+ (NSString *)getCurrentDate:(MT_DateStyle)DataType; {
    return [self conversionTimeStamp:[NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]] DataType:DataType];
}

+ (NSString *)conversionTimeStamp:(NSString *)theTimeStamp DataType:(MT_DateStyle)DataType{
    
    NSTimeInterval time=[theTimeStamp doubleValue];// +28800 因为时差问题要加8小时 == 28800 sec (若需要)
    NSDate *detaildate=[NSDate dateWithTimeIntervalSince1970:time];
    
    NSLog(@"date:%@",[detaildate description]);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    /** switch*/
    switch (DataType) {
        case MT_DateStyleYearMonthDayHourMinuteSec:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        }
            break;
        case MT_DateStyleYearMonthDayHourMinute:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
        }
            break;
            
        case MT_DateStyleYearMonthDayHour:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH"];
        }
            break;
        case MT_DateStyleYearMonthDay:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        }
            break;
        case MT_DateStyleYearMonth:
        {
            [dateFormatter setDateFormat:@"yyyy-MM"];
        }
            break;
        case MT_DateStyleYear:
        {
            [dateFormatter setDateFormat:@"yyyy"];
        }
            break;
        case MT_DateStyleMonthDayHourMinute:
        {
            [dateFormatter setDateFormat:@"MM-dd MM-dd"];
        }
            break;
        case MT_DateStyleDayHourMinute:
        {
            [dateFormatter setDateFormat:@"dd HH:mm"];
        }
            break;
        case MT_DateStyleHour:
        {
            [dateFormatter setDateFormat:@"HH"];
        }
            break;
        case MT_DateStyleMinute:
        {
            [dateFormatter setDateFormat:@"mm"];
        }
            break;
            
            
        default:
            break;
    }
    NSString *currentDateStr = [dateFormatter stringFromDate: detaildate];
    
    return currentDateStr;
}

+(NSString *)DateToString:(NSDate *)date DataType:(MT_DateStyle)DataType{
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    /** switch*/
    switch (DataType) {
        case MT_DateStyleYearMonthDayHourMinuteSec:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        }
            break;
        case MT_DateStyleYearMonthDayHourMinute:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
        }
            break;
            
        case MT_DateStyleYearMonthDayHour:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH"];
        }
            break;
        case MT_DateStyleYearMonthDay:
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        }
            break;
        case MT_DateStyleYearMonth:
        {
            [dateFormatter setDateFormat:@"yyyy-MM"];
        }
            break;
        case MT_DateStyleYear:
        {
            [dateFormatter setDateFormat:@"yyyy"];
        }
            break;
        case MT_DateStyleMonthDayHourMinute:
        {
            [dateFormatter setDateFormat:@"MM-dd MM-dd"];
        }
            break;
        case MT_DateStyleDayHourMinute:
        {
            [dateFormatter setDateFormat:@"dd HH:mm"];
        }
            break;
        case MT_DateStyleHour:
        {
            [dateFormatter setDateFormat:@"HH"];
        }
            break;
        case MT_DateStyleMinute:
        {
            [dateFormatter setDateFormat:@"mm"];
        }
            break;
            
            
        default:
            break;
    }
    NSString *currentDateStr = [dateFormatter stringFromDate: date];
    
    return currentDateStr;
}

+ (NSString *)getMonthFirstAndLastDayWith:(NSString *)dateStr DataType:(MT_DateStyle)DataType{
    
    NSDateFormatter *format=[[NSDateFormatter alloc] init];
    /*这里做下兼容 传递类型为 yyyy-MM-dd 和 yyyy-MM 都是可以的*/
    switch (DataType) {
        case MT_DateStyleYearMonthDay:
        {
            [format setDateFormat:@"yyyy-MM-dd"];
        }
            break;
        case MT_DateStyleYearMonth:
        {
            [format setDateFormat:@"yyyy-MM"];
        }
            break;
            
        default:
            break;
    }
    NSDate *newDate=[format dateFromString:dateStr];
    
    double interval = 0;
    NSDate *firstDate = nil;
    NSDate *lastDate = nil;
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    BOOL OK = [calendar rangeOfUnit:NSCalendarUnitMonth startDate:& firstDate interval:&interval forDate:newDate];
    
    if (OK) {
        lastDate = [firstDate dateByAddingTimeInterval:interval - 1];
    }else {
        return @"-";
    }
    
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *firstString = [myDateFormatter stringFromDate: firstDate];
    NSString *lastString = [myDateFormatter stringFromDate: lastDate];
    NSString *jointStr = [NSString stringWithFormat:@"%@-%@",firstString,lastString];
    return jointStr;
}

+ (NSString *)pleaseInsertStarTime:(NSString *)StarTime andInsertEndTime:(NSString *)EndTime DataType:(MT_DateStyle)DataType{
    // 1.将时间转换为date
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    /** switch*/
    switch (DataType) {
        case MT_DateStyleYearMonthDayHourMinuteSec:
        {
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        }
            break;
        case MT_DateStyleYearMonthDayHourMinute:
        {
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
        }
            break;
            
        case MT_DateStyleYearMonthDayHour:
        {
            [formatter setDateFormat:@"yyyy-MM-dd HH"];
        }
            break;
        case MT_DateStyleYearMonthDay:
        {
            [formatter setDateFormat:@"yyyy-MM-dd"];
        }
            break;
        case MT_DateStyleYearMonth:
        {
            [formatter setDateFormat:@"yyyy-MM"];
        }
            break;
        case MT_DateStyleYear:
        {
            [formatter setDateFormat:@"yyyy"];
        }
            break;
        case MT_DateStyleMonthDayHourMinute:
        {
            [formatter setDateFormat:@"MM-dd MM-dd"];
        }
            break;
        case MT_DateStyleDayHourMinute:
        {
            [formatter setDateFormat:@"dd HH:mm"];
        }
            break;
        case MT_DateStyleHour:
        {
            [formatter setDateFormat:@"HH"];
        }
            break;
        case MT_DateStyleMinute:
        {
            [formatter setDateFormat:@"mm"];
        }
            break;
        default:
            break;
    }
    NSDate *date1 = [formatter dateFromString:StarTime];
    NSDate *date2 = [formatter dateFromString:EndTime];
    // 2.创建日历
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSCalendarUnit type = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    // 3.利用日历对象比较两个时间的差值
    NSDateComponents *cmps = [calendar components:type fromDate:date1 toDate:date2 options:0];
    // 4.输出结果
    NSLog(@"两个时间相差%ld年%ld月%ld日%ld小时%ld分钟%ld秒", cmps.year, cmps.month, cmps.day, cmps.hour, cmps.minute, cmps.second);
    NSString * jointStr = [NSString stringWithFormat:@"两个时间相差%ld年%ld月%ld日%ld小时%ld分钟%ld秒",cmps.year, cmps.month, cmps.day, cmps.hour, cmps.minute, cmps.second];
    return jointStr;
}


+ (NSString *)contrastStartOrEnd:(NSString *)StarTime lateThanHHMMB:(NSString *)EndTime DataType:(MT_DateStyle)DataType{
    if (StarTime.length == EndTime.length) {
        
        // 1.将时间转换为date
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        /** switch*/
        switch (DataType) {
            case MT_DateStyleYearMonthDayHourMinuteSec:
            {
                [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            }
                break;
            case MT_DateStyleYearMonthDayHourMinute:
            {
                [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
            }
                break;
                
            case MT_DateStyleYearMonthDayHour:
            {
                [formatter setDateFormat:@"yyyy-MM-dd HH"];
            }
                break;
            case MT_DateStyleYearMonthDay:
            {
                [formatter setDateFormat:@"yyyy-MM-dd"];
            }
                break;
            case MT_DateStyleYearMonth:
            {
                [formatter setDateFormat:@"yyyy-MM"];
            }
                break;
            case MT_DateStyleYear:
            {
                [formatter setDateFormat:@"yyyy"];
            }
                break;
            case MT_DateStyleMonthDayHourMinute:
            {
                [formatter setDateFormat:@"MM-dd MM-dd"];
            }
                break;
            case MT_DateStyleDayHourMinute:
            {
                [formatter setDateFormat:@"dd HH:mm"];
            }
                break;
            case MT_DateStyleHour:
            {
                [formatter setDateFormat:@"HH"];
            }
                break;
            case MT_DateStyleMinute:
            {
                [formatter setDateFormat:@"mm"];
            }
                break;
            default:
                break;
        }
        
        NSDate *    dateA   = [formatter dateFromString:StarTime];
        NSDate *    dateB   = [formatter dateFromString:EndTime];
        
        NSTimeInterval timeA = [dateA timeIntervalSince1970];
        NSTimeInterval timeB = [dateB timeIntervalSince1970];
        
        if (timeA > timeB) {
            return @"开始时间大";
        } else if (timeA == timeB) {
            return @"时间相等";
        }else if (timeA < timeB){
            return @"开始时间小";
        }else{
            return @"没比出来!传入的值不对";
        }
    }
    return @"没比出来!传入的值不对";
}
@end

