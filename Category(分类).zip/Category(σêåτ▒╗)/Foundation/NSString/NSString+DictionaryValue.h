//
//  NSString+Dictionary.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 14-6-13.
//  Copyright (c) 2014年 辛忠志. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (DictionaryValue)
/**
 *  @brief  JSON字符串转成NSDictionary
 *
 *  @return NSDictionary
 */
-(NSDictionary *) dictionaryValue;
@end
