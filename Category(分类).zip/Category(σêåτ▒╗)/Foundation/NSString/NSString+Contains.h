//
//  NSString+Contains.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/5/9.
//  Copyright (c) 2015年 X了个J All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Contains)

/**
 *  @brief  验证包含特殊字符
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkContainSpecialCharacter;


/**
 *  @brief  验证只是大写字母
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkCapitalLetter;


/**
 *  @brief  验证只是小写字母
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkJustLowercase;



/**
 *  @brief  验证只是字母
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkJustLetter;



/**
 *  @brief  验证只是汉字
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkJustChinese;

/**
 *  @brief  验证URL
 *
 *  @return 返回值：验证结果
 */

- (BOOL)checkURL;

/**
 *  @brief
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkJustNumber;



/**
 *  @brief  验证邮箱
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkEmail;

/**
 *  @brief  验证身份证
 *
 *  @return 返回值：验证结果
 */
- (BOOL)checkIDCard;

/**
 *  @brief  验证电话号码
 *
 *  @return 返回值：验证结果
 */

- (BOOL)checkTelephoneNumber;


/**
 *  @brief  正则验证(通用) regex 正则表达式
 *
 *  @return 返回值：验证结果
 */
- (BOOL)regular:(NSString *)regex;


/**
 *  @brief  判断字符串是否为空(@"") && null
 *
 *  @return 是否为空(@"") && null
 */
- (BOOL) isBlankString;


/**
 *  @brief  判断URL中是否包含中文
 *
 *  @return 是否包含中文
 */
- (BOOL)isContainChinese;
/**
 *  @brief  是否包含空格
 *
 *  @return 是否包含空格
 */
- (BOOL)isContainBlank;

/**
 *  @brief  Unicode编码的字符串转成NSString
 *
 *  @return Unicode编码的字符串转成NSString
 */
- (NSString *)makeUnicodeToString;

- (BOOL)containsCharacterSet:(NSCharacterSet *)set;
/**
 *  @brief 是否包含字符串
 *
 *  @param string 字符串
 *
 *  @return YES, 包含;
 */
- (BOOL)containsaString:(NSString *)string;
/**
 *  @brief 获取字符数量
 */
- (int)wordsCount;

@end
