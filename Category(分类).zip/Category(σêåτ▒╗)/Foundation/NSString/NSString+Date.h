//
//  NSString+Date.h
//  QiJingVR
//
//  Created by 辛忠志 on 16/6/25.
//  Copyright © 2016年 X了个J. All rights reserved.
//
//  修订: 2018 - 12 - 05 增加一些接口 为了避免项目报错 原本的接口继续保留～
//       之所以添加新的接口 是因为原本接口 并不智能～(也可用 只不过没有枚举值和一些优化判断)
//
//
#import <Foundation/Foundation.h>


typedef NS_ENUM(NSInteger,MT_DateStyle) {
    MT_DateStyleYearMonthDayHourMinuteSec = 0, /*年月日 时分秒*/
    MT_DateStyleYearMonthDayHourMinute , /*年月日 时分*/
    MT_DateStyleYearMonthDayHour, /*年月日时*/
    MT_DateStyleYearMonthDay,/*年月日*/
    MT_DateStyleYearMonth, /*年月*/
    MT_DateStyleYear, /*年*/
    MT_DateStyleMonthDayHourMinute,/*月日 时分*/
    MT_DateStyleDayHourMinute,/*日时分*/
    MT_DateStyleHour,/*时*/
    MT_DateStyleMinute,/*分*/
};


@interface NSString (Date)
/** 计算时间差 */
+ (NSString *)intervalFromLastDate:(NSString *)dateString1 toTheDate:(NSString *)dateString2;
/** 时间戳转时间 */
+ (NSString *)conversionTimeStamp:(NSString *)theTimeStamp;
/*时间戳转时间 但是要若干个 月 eg: 7月10 变为 8月10 */
+ (NSString *)conversionTimeStampAddOneMonth:(NSString *)theTimeStamp addMonthCount:(int)monthCount;
/** 获取当前时间 */
+ (NSString *)getCurrentDate;
/*获取当前时间 dateType 为类型 yyyy-MM-dd hh:mm:ss */
+ (NSString *)getTimeString:(NSString *)dateType;
/** 秒转时间 */
+ (NSString *)timeFormatted:(int)totalSeconds;
/** 获取时间戳 */
+ (NSString *)getcurrentTimetamp;
/* 毫秒转时间 **/
+ (NSString *)ConvertStrToTime:(NSString *)timeStr;
/*获取当前时间并在此基础上加上若干月 12个 24个 ---- */
+ (NSString *)getCurrentDateAddMonth:(int)addData;
/* 毫秒转时间(中文) **/
+ (NSString *)ChineseConvertStrToTime:(NSString *)timeStr;
/* 毫秒转时间(小时) **/
+ (NSString *)ConvertStrToDetialTime:(NSString *)timeStr;
/*IOS 获取指定月的第一天和最后一天*/
+ (NSString *)getMonthBeginAndEndWith:(int)monthCount;
/*时间转时间戳*/
+(NSInteger)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format;
/*获取指定时间并在此基础上加上若干月*/
+ (NSString *)getAssignCurrentDateAddMonth:(int)addData timeData:(NSString *)data;

/*时间戳转时间 NSDate 转 NSString
 date 传你要转的date
 dateFormatterType 为当前date类型值 不知道传啥的话 直接看里面实现 写的很清晰~
 */
+(NSString *)DateToString:(NSDate *)date dateFormatterType:(NSString *)dateFormatterType;



#pragma mark - 新版接口(推荐)
/**
 *
 * 根据 DateStyle 枚举值 去获取当前 年 月 日 时 分 秒 任意组合
 *
 栗子:  NSString * str = [NSString getCurrentDate:DateStyleYearMonthDayHourMinuteSec];
 */
+ (NSString *)getCurrentDate:(MT_DateStyle)DataType;

/**
 *   NSDate 转 NSString
 *   date 传你要转的date
 *   DataType 为当前date类型值(枚举值) 不知道传啥的话 直接看里面实现 写的很清晰~
 */
+(NSString *)DateToString:(NSDate *)date DataType:(MT_DateStyle)DataType;



/**
 *  获取指定 月份的第一天和最后一天！！
 *  dateStr  年月日 或 年月 (2018-09-18 或 2019-09)
 *  DataType 枚举值(可选     DateStyleYearMonthDay年月日  DateStyleYearMonth 年月)
 
 *  栗子1:     NSString * str1 = [NSString getMonthFirstAndLastDayWith:@"2018-09-10" DataType:DateStyleYearMonthDay];
 栗子2:     NSString * str2 = [NSString getMonthFirstAndLastDayWith:@"2018-09" DataType:DateStyleYearMonth];
 */

+ (NSString *)getMonthFirstAndLastDayWith:(NSString *)dateStr DataType:(MT_DateStyle)DataType;

/**
 *  计算时间差 给定两个指定的 时间字符串 再给 一个时间的类型即可完成操作
 *  StarTime 开始时间  年月日 或 年月 等等～ (2018-09-18 或 2019-09)
 *  EndTime  结束时间  年月日 或 年月 等等～ (2018-09-18 或 2019-09)
 *  DataType 枚举值(可选     DateStyleYearMonthDay年月日  DateStyleYearMonth 年月)
 
 *  栗子1:     NSString * str1 = [NSString pleaseInsertStarTime:@"2018-10-10" andInsertEndTime:@"2019-10-20" DataType:DateStyleYearMonthDay];
 栗子2:     NSString * str1 = [NSString pleaseInsertStarTime:@"2018-10" andInsertEndTime:@"2019-09" DataType:DateStyleYearMonth];
 */
+ (NSString *)pleaseInsertStarTime:(NSString *)StarTime andInsertEndTime:(NSString *)EndTime DataType:(MT_DateStyle)DataType;

/**
 *  比较两个时间的大小
 *  StarTime 开始时间  年月日 或 年月 等等～ (2018-09-18 或 2019-09)
 *  EndTime  结束时间  年月日 或 年月 等等～ (2018-09-18 或 2019-09)
 *  DataType 枚举值(可选     DateStyleYearMonthDay年月日  DateStyleYearMonth 年月)
 
 *  栗子1:     NSString * str1 = [NSString contrastStartOrEnd:@"2018-10" lateThanHHMMB:@"2017-10" DataType:DateStyleYearMonth];
 
 return: @"开始时间大" @"时间相等" @"开始时间小" @"没比出来!传入的值不对"
 */
+ (NSString *)contrastStartOrEnd:(NSString *)StarTime lateThanHHMMB:(NSString *)EndTime DataType:(MT_DateStyle)DataType;
@end
