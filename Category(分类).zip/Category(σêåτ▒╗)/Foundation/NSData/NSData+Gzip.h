//
//  NSData+Gzip.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 14/12/30.
//  Copyright (c) 2014年 X了个J. All rights reserved.
//


//Add libz.dylib to your project.
#import <Foundation/Foundation.h>
extern NSString* const GzipErrorDomain;
@interface NSData (Gzip)
/**
 *  @brief  GZIP压缩
 *
 *  @param level 压缩级别
 *
 *  @return 压缩后的数据
 */
- (NSData *)gzippedDataWithCompressionLevel:(float)level;

/**
 *  @brief  GZIP压缩 压缩级别 默认-1
 *
 *  @return 压缩后的数据
 */
- (NSData *)gzippedData;

/**
 *  @brief  GZIP解压
 *
 *  @return 解压后数据
 */
- (NSData *)gunzippedData;
@end
