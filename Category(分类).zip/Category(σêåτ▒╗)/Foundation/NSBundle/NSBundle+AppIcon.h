//
//  NSBundle+AppIcon.h
//
//  Created by 辛忠志 on 16/12/15.
//  Copyright (c) 2016年 X了个J. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSBundle (AppIcon)
/*
 time(时间): 16/12/15.
 
 description(描述): appIconPath路径获取
 
 @param: appIconPath  路径
 ... ...
 */
- (NSString*)appIconPath ;

/*
 time(时间): 16/12/15.
 
 description(描述): appIcon获取
 
 @param: appIcon  图片
 ... ...
 */
- (UIImage*)appIcon ;
@end
