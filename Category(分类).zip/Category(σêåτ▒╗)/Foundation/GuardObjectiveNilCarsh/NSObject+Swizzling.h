//
//  MTSafeManager.h
//  解耦Demo
//
//  Created by 辛忠志 on 2018/9/25.
//  Copyright © 2018年 X了个J. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface NSObject (Swizzling)

+ (void)swizzleSelector:(SEL)originalSelector withSwizzledSelector:(SEL)swizzledSelector;

@end
