//
//  NSMutableArray+NilSafe.m
//
//  Created by 辛忠志 on 2018/9/27.
//  Copyright © 2018年 X了个J. All rights reserved.
//
//

/*  注释: 首先膜拜一句～ 黑魔大法好 黑魔大法好 黑魔大法好
 本分类为不可变数组分类 可能产生的 不可变数组 类簇的展示形式 可能会出现以下几种样式
        __NSArrayM  __NSCFArray(暂时么写 因为和 __NSArrayM 只要方法冲突就会崩溃 所以暂时没写)
        当然以上类簇形式可能会产生 越界 崩溃的方法如下~~~~~~
        objectAtIndex
        subarrayWithRange
        objectAtIndexedSubscript
        addObject
        insertObject:atIndex:
        removeObjectAtIndex:
        replaceObjectAtIndex:withObject:
        removeObjectsInRange:
 */

#import "NSMutableArray+NilSafe.h"
#import "NSObject+Swizzling.h"
#import <objc/runtime.h>

@implementation NSMutableArray (NilSafe)

+ (void)load{
    
#if DEBUG
    
#else
    static dispatch_once_t onceToken;
    //调用原方法以及新方法进行交换，处理崩溃问题。
    dispatch_once(&onceToken, ^{
        
        //越界崩溃方式一： __NSArrayM 类型
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(safeObjectAtIndex:)];
        //        [NSMutableArray arrayWithObjects:@"1",@"1",@"2",@""@"3", nil];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscriptNSArrayM:)];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRangeNSArrayM:)];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(addObject:) withSwizzledSelector:@selector(safeaddObjectNSArrayM:)];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(insertObject:atIndex:) withSwizzledSelector:@selector(safeinsertObjectNSArrayM:atIndex:)];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(removeObjectAtIndex:) withSwizzledSelector:@selector(saferemoveObjectAtIndexNSArrayM:)];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(replaceObjectAtIndex:withObject:) withSwizzledSelector:@selector(safereplaceObjectAtIndexNSArrayM:withObject:)];
        [objc_getClass("__NSArrayM") swizzleSelector:@selector(removeObjectsInRange:) withSwizzledSelector:@selector(saferemoveObjectsInRangeNSArrayM:)];
        
        
        
        //越界崩溃方式二： __NSCFArray 类型
        //        [objc_getClass("__NSCFArray") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(hookObjectAtIndexhookObjectAtIndex:)];
        //        [objc_getClass("__NSCFArray") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRangeNSCFArray:)];
        //        [objc_getClass("__NSCFArray") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscriptNSCFArray:)];
        //        [objc_getClass("__NSCFArray") swizzleSelector:@selector(addObject:) withSwizzledSelector:@selector(safeaddObjectNSCFArray:)];
        //        [objc_getClass("__NSCFArray") swizzleSelector:@selector(insertObject:atIndex:) withSwizzledSelector:@selector(safeinsertObjectNSCFArray:atIndex:)];
        //        [objc_getClass("__NSCFArray") swizzleSelector:@selector(removeObjectAtIndex:) withSwizzledSelector:@selector(saferemoveObjectAtIndexNSCFArray:)];
        
    });
#endif
    
    
}

#pragma mark - __NSArrayM

- (instancetype)safeObjectAtIndex:(NSUInteger)index {
    // 数组越界也不会崩，但是开发的时候并不知道数组越界
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safeObjectAtIndex:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safeObjectAtIndex:index];
    }
}
- (instancetype)safeobjectAtIndexedSubscriptNSArrayM:(NSUInteger)index {
    // 数组越界也不会崩，但是开发的时候并不知道数组越界
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safeobjectAtIndexedSubscriptNSArrayM:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safeobjectAtIndexedSubscriptNSArrayM:index];
    }
}
- (instancetype)safesubarrayWithRangeNSArrayM:(NSUInteger)index {
    // 数组越界也不会崩，但是开发的时候并不知道数组越界
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safesubarrayWithRangeNSArrayM:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safesubarrayWithRangeNSArrayM:index];
    }
}
- (void) safeaddObjectNSArrayM:(id)anObject {
    if (anObject) {
        [self safeaddObjectNSArrayM:anObject];
    }else{
        @try {
            return [self safeaddObjectNSArrayM:anObject];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
        } @finally {
        }
    }
}

- (void) safeinsertObjectNSArrayM:(id)anObject atIndex:(NSUInteger)index {
    if (anObject && index <= self.count) {
        [self safeinsertObjectNSArrayM:anObject atIndex:index];
    }else{
        @try {
            [self safeinsertObjectNSArrayM:anObject atIndex:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
        } @finally {
        }
    }
}

- (void) saferemoveObjectAtIndexNSArrayM:(NSUInteger)index {
    if (index < self.count) {
        [self saferemoveObjectAtIndexNSArrayM:index];
    }else{
        @try {
            [self saferemoveObjectAtIndexNSArrayM:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
        } @finally {
        }
    }
}

- (void) safereplaceObjectAtIndexNSArrayM:(NSUInteger)index withObject:(id)anObject {
    if (index < self.count && anObject) {
        [self safereplaceObjectAtIndexNSArrayM:index withObject:anObject];
    }else{
        @try {
            [self saferemoveObjectAtIndexNSArrayM:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
        } @finally {
        }
    }
}

- (void) saferemoveObjectsInRangeNSArrayM:(NSRange)range {
    if (range.location + range.length <= self.count) {
        [self saferemoveObjectsInRangeNSArrayM:range];
    }else{
        @try {
            [self saferemoveObjectsInRangeNSArrayM:range];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 可变数组越界～");
        } @finally {
        }
    }
}
#pragma mark - __NSCFArray

- (instancetype)safeObjectAtIndexNSCFArray:(NSUInteger)index {
    // 数组越界也不会崩，但是开发的时候并不知道数组越界
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safeObjectAtIndexNSCFArray:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式二 之 可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safeObjectAtIndexNSCFArray:index];
    }
}
//
//
//- (instancetype)safesubarrayWithRangeNSCFArray:(NSUInteger)index {
//    // 数组越界也不会崩，但是开发的时候并不知道数组越界
//    if (index > (self.count - 1)) { // 数组越界
//        @try {
//            return [self safesubarrayWithRangeNSCFArray:index];
//        } @catch (NSException *exception) {
//            NSLog(@"越界崩溃方式二 之 可变数组越界～");
//            return nil;
//        } @finally {
//        }
//    }else { // 没有越界
//        return [self safesubarrayWithRangeNSCFArray:index];
//    }
//}
//- (instancetype)safeobjectAtIndexedSubscriptNSCFArray:(NSUInteger)index {
//    // 数组越界也不会崩，但是开发的时候并不知道数组越界
//    if (index > (self.count - 1)) { // 数组越界
//        @try {
//            return [self safeobjectAtIndexedSubscriptNSCFArray:index];
//        } @catch (NSException *exception) {
//            NSLog(@"越界崩溃方式二 之 可变数组越界～");
//            return nil;
//        } @finally {
//        }
//    }else { // 没有越界
//        return [self safeobjectAtIndexedSubscriptNSCFArray:index];
//    }
//}
//- (void) safeaddObjectNSCFArray:(id)anObject {
//    if (anObject) {
//        [self safeaddObjectNSCFArray:anObject];
//    }else{
//        @try {
//            return [self safeaddObjectNSCFArray:anObject];
//        } @catch (NSException *exception) {
//            NSLog(@"越界崩溃方式二 之 可变数组越界～");
//        } @finally {
//        }
//    }
//}
//
//- (void) safeinsertObjectNSCFArray:(id)anObject atIndex:(NSUInteger)index {
//    if (anObject && index <= self.count) {
//        [self safeinsertObjectNSCFArray:anObject atIndex:index];
//    }else{
//        @try {
//            [self safeinsertObjectNSCFArray:anObject atIndex:index];
//        } @catch (NSException *exception) {
//            NSLog(@"越界崩溃方式二 之 可变数组越界～");
//        } @finally {
//        }
//    }
//}
//
//

@end
