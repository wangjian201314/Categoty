//
//  NSArray+NilSafe.h
//
//  Created by 辛忠志 on 2018/9/25.
//  Copyright © 2018年 X了个J. All rights reserved.
//
//
/*  注释: 首先膜拜一句～ 黑魔大法好 黑魔大法好 黑魔大法好
          本分类为不可变数组分类 可能产生的 不可变数组 类簇的展示形式 可能会出现以下几种样式
          __NSArray0  __NSArrayI   __NSArrayI_Transfer  __NSSingleObjectArrayI  __NSFrozenArrayM  __NSArrayReversed
        当然以上类簇形式可能会产生 越界 崩溃的方法如下~~~~~~
        objectAtIndex
        objectAtIndexedSubscript
        subarrayWithRange
 */


#import "NSArray+NilSafe.h"
#import <objc/runtime.h>
#import "NSObject+Swizzling.h"//在NSString类别中交换方法

@implementation NSArray (NilSafe)

+ (void)load{
    static dispatch_once_t onceToken;
    //调用原方法以及新方法进行交换，处理崩溃问题。
    
     
        
        
#if DEBUG
        

        
    
#else
    dispatch_once(&onceToken, ^{
        //越界崩溃方式一：[array objectAtIndex:1000];
        [objc_getClass("__NSArrayI") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(safeObjectAtIndex:)];
        [objc_getClass("__NSArrayI") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscript:)];
        [objc_getClass("__NSArrayI") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRange:)];
        
        
        
        //越界崩溃方式二：[[NSArray alloc]initWithObjects:@"1", nil]; above iOS10
        [objc_getClass("__NSSingleObjectArrayI") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(safeObjectAtIndexNSSingleObjectArrayI:)];
        [objc_getClass("__NSSingleObjectArrayI") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscriptNSSingleObjectArrayI:)];
        [objc_getClass("__NSSingleObjectArrayI") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRangeNSSingleObjectArrayI:)];
        
        
        //越界崩溃方式三：NSArray * arr3 = [NSArray new];
        [objc_getClass("__NSArray0") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(safeObjectAtIndexNSArray0:)];
        [objc_getClass("__NSArray0") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscriptNSArray0:)];
        [objc_getClass("__NSArray0") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRangeNSArray0:)];
        
        
        
        //越界崩溃方式四：__NSArrayI_Transfer
        [objc_getClass("__NSArrayI_Transfer") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(safeObjectAtIndexNSArrayI_Transfer:)];
        [objc_getClass("__NSArrayI_Transfer") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscriptNSArrayI_Transfer:)];
        [objc_getClass("__NSArrayI_Transfer") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRangeNSArrayI_Transfer:)];
        
        
        //越界崩溃方式五：__NSArrayReversed
        [objc_getClass("__NSArrayReversed") swizzleSelector:@selector(objectAtIndex:) withSwizzledSelector:@selector(safeObjectAtIndexNSArrayReversed:)];
        [objc_getClass("__NSArrayReversed") swizzleSelector:@selector(objectAtIndexedSubscript:) withSwizzledSelector:@selector(safeobjectAtIndexedSubscriptNSArrayReversed:)];
        [objc_getClass("__NSArrayReversed") swizzleSelector:@selector(subarrayWithRange:) withSwizzledSelector:@selector(safesubarrayWithRangeNSArrayReversed:)];
    });
#endif
}

#pragma mark - __NSArrayI

- (instancetype)safeObjectAtIndex:(NSUInteger)index {
    // 数组越界也不会崩，但是开发的时候并不知道数组越界
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safeObjectAtIndex:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式一 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safeObjectAtIndex:index];
    }
}
- (instancetype)safeobjectAtIndexedSubscript:(NSUInteger)index{
    
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safeobjectAtIndexedSubscript:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 不可变数组越界～ ");
            NSAssert(1, @"越界崩溃方式一 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safeobjectAtIndexedSubscript:index];
    }
}
- (instancetype)safesubarrayWithRange:(NSUInteger)index{
    
    if (index > (self.count - 1)) { // 数组越界
        @try {
            return [self safesubarrayWithRange:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式一 之 不可变数组越界～ ");
            NSAssert(1, @"越界崩溃方式一 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }else { // 没有越界
        return [self safesubarrayWithRange:index];
    }
}


#pragma mark - __NSSingleObjectArrayI

- (instancetype) safeObjectAtIndexNSSingleObjectArrayI:(NSUInteger)index {
    if (index < self.count) {
        return [self safeObjectAtIndexNSSingleObjectArrayI:index];
    }
    else{
        @try {
            return [self safeObjectAtIndexNSSingleObjectArrayI:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式二 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式二 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}
- (instancetype) safeobjectAtIndexedSubscriptNSSingleObjectArrayI:(NSUInteger)index {
    if (index < self.count) {
        return [self safeobjectAtIndexedSubscriptNSSingleObjectArrayI:index];
    }
    else{
        @try {
            return [self safeobjectAtIndexedSubscriptNSSingleObjectArrayI:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式二 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式二 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

- (instancetype) safesubarrayWithRangeNSSingleObjectArrayI:(NSUInteger)index {
    if (index < self.count) {
        return [self safesubarrayWithRangeNSSingleObjectArrayI:index];
    }
    else{
        @try {
            return [self safesubarrayWithRangeNSSingleObjectArrayI:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式二 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式二 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

#pragma mark - __NSArray0
- (instancetype) safeObjectAtIndexNSArray0:(NSUInteger)index {
    if (index < self.count) {
        return [self safeObjectAtIndexNSArray0:index];
    }
    else{
        @try {
            return [self safeObjectAtIndexNSArray0:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式三 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式二 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

- (instancetype) safeobjectAtIndexedSubscriptNSArray0:(NSUInteger)index {
    if (index < self.count) {
        return [self safeobjectAtIndexedSubscriptNSArray0:index];
    }
    else{
        @try {
            return [self safeobjectAtIndexedSubscriptNSArray0:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式三 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式二 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

- (instancetype) safesubarrayWithRangeNSArray0:(NSUInteger)index {
    if (index < self.count) {
        return [self safesubarrayWithRangeNSArray0:index];
    }
    else{
        @try {
            return [self safesubarrayWithRangeNSArray0:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式三 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式三 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

#pragma mark - __NSArrayI_Transfer
- (instancetype) safeObjectAtIndexNSArrayI_Transfer:(NSUInteger)index {
    if (index < self.count) {
        return [self safeObjectAtIndexNSArrayI_Transfer:index];
    }
    else{
        @try {
            return [self safeObjectAtIndexNSArrayI_Transfer:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式四 之 不可变数组越界～");
            NSAssert(1, @"越界崩溃方式四 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

- (instancetype) safeobjectAtIndexedSubscriptNSArrayI_Transfer:(NSUInteger)index {
    if (index < self.count) {
        return [self safeobjectAtIndexedSubscriptNSArrayI_Transfer:index];
    }
    else{
        @try {
            return [self safeobjectAtIndexedSubscriptNSArrayI_Transfer:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式四 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

- (instancetype) safesubarrayWithRangeNSArrayI_Transfer:(NSUInteger)index {
    if (index < self.count) {
        return [self safesubarrayWithRangeNSArrayI_Transfer:index];
    }
    else{
        @try {
            return [self safesubarrayWithRangeNSArrayI_Transfer:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式四 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

#pragma mark - __NSArrayReversed
- (instancetype) safeObjectAtIndexNSArrayReversed:(NSUInteger)index {
    if (index < self.count) {
        return [self safeObjectAtIndexNSArrayReversed:index];
    }
    else{
        @try {
            return [self safeObjectAtIndexNSArrayReversed:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式五 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}
- (instancetype) safeobjectAtIndexedSubscriptNSArrayReversed:(NSUInteger)index {
    if (index < self.count) {
        return [self safeobjectAtIndexedSubscriptNSArrayReversed:index];
    }
    else{
        @try {
            return [self safeobjectAtIndexedSubscriptNSArrayReversed:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式五 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

- (instancetype) safesubarrayWithRangeNSArrayReversed:(NSUInteger)index {
    if (index < self.count) {
        return [self safesubarrayWithRangeNSArrayReversed:index];
    }
    else{
        @try {
            return [self safesubarrayWithRangeNSArrayReversed:index];
        } @catch (NSException *exception) {
            NSLog(@"越界崩溃方式五 之 不可变数组越界～");
            return nil;
        } @finally {
        }
    }
}

@end






