//
//  NSDictionary+JSONString.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/4/25.
//  Copyright (c) 2015年 X了个J. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (JSONString)
/**
 *  @brief NSDictionary转换成JSON字符串
 *
 *  @return  JSON字符串
 */
-(NSString *)JSONString;
@end
