//
//  UIVIew+Debug.h
//  Constraints_Hybrid
//
//  Created by Eric Rolf on 1/3/13.
//  Copyright (c) 2013 Cardinal Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@interface UIView (Debug)

@end
