//
//  UIView+Screenshot.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/1/10.
//  Copyright (c) 2015年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Screenshot)
/**
 *  @brief  view截图
 *
 *  @return 截图
 */
- (UIImage *)screenshot;

/**
 *  @author 辛忠志
 *
 *  @brief  截图一个view中所有视图 包括旋转缩放效果
 *
 *  @param aView    一个view
 *  @param limitWidth 限制缩放的最大宽度 保持默认传0
 *
 *  @return 截图
 */
- (UIImage *)screenshot:(CGFloat)maxWidth;
@end
