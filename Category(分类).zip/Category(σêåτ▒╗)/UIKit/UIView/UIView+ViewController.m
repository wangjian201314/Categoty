//
//  UIView+ViewController.m
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/5/9.
//  Copyright (c) 2015年 X了个J All rights reserved.
//

#import "UIView+ViewController.h"

@implementation UIView (ViewController)
/**
 *  @brief  找到当前view所在的viewcontroler
 */
- (UIViewController *)viewController
{
    UIResponder *responder = self.nextResponder;
    do {
        if ([responder isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)responder;
        }
        responder = responder.nextResponder;
    } while (responder);
    return nil;
}

@end
