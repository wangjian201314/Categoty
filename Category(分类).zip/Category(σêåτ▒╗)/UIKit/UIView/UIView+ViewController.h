//
//  UIView+ViewController.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/5/9.
//  Copyright (c) 2015年 X了个J All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewController)
/**
 *  @brief  找到当前view所在的viewcontroler
 */
@property (readonly) UIViewController *viewController;

@end
