//
//  UIWebView+loadURL.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 14/12/15.
//  Copyright (c) 2014年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebView (Load)
/**
 *  @brief  读取一个网页地址
 *
 *  @param URLString 网页地址
 */
- (void)loadURL:(NSString*)URLString;
/**
 *  @brief  读取bundle中的webview
 *
 *  @param htmlName webview名称
 */
- (void)loadLocalHtml:(NSString*)htmlName;
/**
 *  @brief  清空cookie
 */
- (void)clearCookies;
@end
