//
//  UIAlertView+Block.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/5/9.
//  Copyright (c) 2015年 X了个J All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^UIAlertViewCallBackBlock)(NSInteger buttonIndex);

@interface UIAlertView (Block)<UIAlertViewDelegate>

@property (nonatomic, copy) UIAlertViewCallBackBlock alertViewCallBackBlock;



/**
   栗子如下(请复制)~~~~~~~~
 
 * [UIAlertView alertWithCallBackBlock:^(NSInteger buttonIndex) {
    
 } title:@"title" message:@"meeage" cancelButtonName:@"取消" otherButtonTitles:@"确定", nil];
 *
 *
 *
 */
+ (void)alertWithCallBackBlock:(UIAlertViewCallBackBlock)alertViewCallBackBlock title:(NSString *)title message:(NSString *)message  cancelButtonName:(NSString *)cancelButtonName otherButtonTitles:(NSString *)otherButtonTitles, ...NS_REQUIRES_NIL_TERMINATION;

@end
