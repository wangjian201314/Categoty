//
//  UIViewController+Visible.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 14/12/15.
//  Copyright (c) 2014年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Visible)
- (BOOL)isVisible;

@end
