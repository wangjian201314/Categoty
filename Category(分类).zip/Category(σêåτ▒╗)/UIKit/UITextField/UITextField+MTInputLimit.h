//
//  UITextField+JKInputLimit.h
//  JKCategories 
//
//  Created by 辛忠志 on 2016/11/29.
//  Copyright © 2016年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (MTInputLimit)
@property (assign, nonatomic)  NSInteger jk_maxLength;//if <=0, no limit
@end
