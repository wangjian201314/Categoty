//
//  BaseLabel.m
//  
//
//  Created by 辛忠志 on 2018/6/7.
//

#import "BaseLabel.h"
#import <UIKit/UIKit.h>



@implementation BaseLabel

- (void)drawTextInRect:(CGRect)rect {
    //文字距离上下左右边框都有10单位的间隔
    CGRect newRect = CGRectMake(rect.origin.x , rect.origin.y , rect.size.width, rect.size.height);
    [super drawTextInRect:newRect];
}

@end
