//
//  BaseLabel.h
//  
//
//  Created by 辛忠志 on 2018/6/7.
//

#import <UIKit/UIKit.h>

@interface BaseLabel : UILabel

@end
