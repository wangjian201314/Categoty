//
//  UILabel+ChangeLineSpaceAndWordSpace.m
//  MTCommon
//
//  Created by luojian on 2018/9/18.
//  Copyright © 2018年 mastercom. All rights reserved.
//

#import "UILabel+ChangeLineSpaceAndWordSpace.h"

@implementation UILabel (ChangeLineSpaceAndWordSpace)

/**
 改变label的行间距
 ⚠️如果需要同时改变行距和字间距，请用lineSpace: WordSpace:

 @param space 行间距大小
 */
- (void)lineSpace:(float)space {
    UILabel *label = self;
    NSString *labelText = label.text;
    
    NSMutableAttributedString *attributedString = [label.attributedText mutableCopy];
    if (!attributedString) {
        attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    }
    
    //NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:space];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    label.attributedText = attributedString;
    [label sizeToFit];
}

/**
 改变label的字间距
 ⚠️如果需要同时改变行距和字间距，请用lineSpace: WordSpace:

 @param space 字间距大小
 */
- (void)wordSpace:(float)space {
    UILabel *label = self;
    NSString *labelText = label.text;
    NSMutableAttributedString *attributedString = [label.attributedText mutableCopy];
    if (!attributedString) {
        attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    }
    //NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText attributes:@{NSKernAttributeName:@(space)}];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    label.attributedText = attributedString;
    [label sizeToFit];
    
}

/**
 改变label的行间距和字间距

 @param lineSpace 行间距大小
 @param wordSpace 字间距大小
 */
- (void)lineSpace:(float)lineSpace WordSpace:(float)wordSpace {
    UILabel *label = self;
    NSString *labelText = label.text;
    NSMutableAttributedString *attributedString = [label.attributedText mutableCopy];
    if (!attributedString) {
        attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    }
    //NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText attributes:@{NSKernAttributeName:@(wordSpace)}];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:lineSpace];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    label.attributedText = attributedString;
    [label sizeToFit];
    
}



@end
