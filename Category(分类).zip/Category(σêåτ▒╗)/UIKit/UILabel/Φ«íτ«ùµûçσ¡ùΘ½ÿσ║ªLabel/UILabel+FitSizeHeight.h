//
//  UILabel+FitSizeHeight.h
//  MTCommon
//
//  Created by 辛忠志 on 2018/11/19.
//  Copyright © 2018年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (FitSizeHeight)

/**
 *  计算文字高度
 *  根据当前label的宽度 字体大小 计算文字高度
 *  @param  fontSize    label字体大小
 */
-(CGRect)FitSizeHeight:(CGFloat)fontSize;
@end

NS_ASSUME_NONNULL_END
