//
//  UILabel+FitSizeHeight.h
//  MTCommon
//
//  Created by 辛忠志 on 2018/11/19.
//  Copyright © 2018年 X了个J. All rights reserved.
//


#import "UILabel+FitSizeHeight.h"

@implementation UILabel (FitSizeHeight)

/**
 *  计算文字高度
 *  根据当前label的宽度 字体大小 计算文字高度
 *  @param  fontSize    label字体大小
 */
-(CGRect)FitSizeHeight:(CGFloat)fontSize{
    /*这里发现 系统会识别当前label的字体样式 如果你仅仅只是传递了font 并没有传递 字体类型的话 那么可能会导致计算高度不准确   默认情况下使用系统字体计算高度 fontWithName 为nil */
    
    self.font  = [UIFont fontWithName:nil size:fontSize];
    CGRect rect = [self.text boundingRectWithSize:CGSizeMake(self.frame.size.width , MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]} context:nil];
    return rect;
}
@end
