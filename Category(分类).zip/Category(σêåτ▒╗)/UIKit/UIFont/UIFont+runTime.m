//
//  UIFont+runTime.m
//  UIFont 适配
//
//  Created by 辛忠志 on 2018/11/19.
//  Copyright © 2018年 X了个J. All rights reserved.
/**
 *   和UI组长陈济敦沟通过 UI原型图在制作的时候是按照IPhone6 的像素进行适配的(宽度375px) 举个例子: Label 在 IPhone6上的字号为14 ,那么在IPhone6s 上的字号就应该为 14*(屏宽/375) 以此类推～ 现在利用runTime方法调换的机制将 systemFontOfSize 方法替换为 adjustFont 方法 ~
     这样做的目的是什么呢？？ 就是为了根据不同机型 展示不同字号的文字 ～
 */

#define MTSCREEN_WIDTH_BaseFont 375

#import "UIFont+runTime.h"
#import <objc/runtime.h>

@implementation UIFont (runTime)
+ (void)load {
    // 获取替换后的类方法
    Method newMethod = class_getClassMethod([self class], @selector(adjustFont:));
    // 获取替换前的类方法
    Method method = class_getClassMethod([self class], @selector(systemFontOfSize:));
    // 然后交换类方法，交换两个方法的IMP指针，(IMP代表了方法的具体的实现）
    method_exchangeImplementations(newMethod, method);
}

+ (UIFont *)adjustFont:(CGFloat)fontSize {
    UIFont *newFont = nil;
    newFont = [UIFont adjustFont:fontSize * [UIScreen mainScreen].bounds.size.width/MTSCREEN_WIDTH_BaseFont];
    return newFont;
}

@end
