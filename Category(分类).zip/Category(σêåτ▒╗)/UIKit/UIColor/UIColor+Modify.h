//
//  UIColor+Modify.h
//  iOS-Categories 
//
//  Created by 辛忠志 on 15/1/2.
//  Copyright (c) 2015年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Modify)
- (UIColor *)invertedColor;
- (UIColor *)colorForTranslucency;
- (UIColor *)lightenColor:(CGFloat)lighten;
- (UIColor *)darkenColor:(CGFloat)darken;
@end
