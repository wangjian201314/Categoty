//
//  UIWindow+Hierarchy.h

//  Created by 辛忠志 on 16/1/16.
//  Copyright (c) 2015年 X了个J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Hierarchy)
/*!
 @method topMostController
 
 @return Returns the current Top Most ViewController in hierarchy.(返回当前层次结构中最顶层的ViewController。) 郭文超强迫我的～ 
 */

+(UIViewController *)topViewController;

/*!
 @method topMostController
 
 @return Returns the current Top Most ViewController in hierarchy.(返回当前层次结构中最顶层的ViewController。)
 */
- (UIViewController*) topMostController;

/*!
 @method currentViewController
 
 @return Returns the topViewController in stack of topMostController.(返回topMostController堆栈中的topViewController。)
 */
- (UIViewController*)currentViewController;
@end
