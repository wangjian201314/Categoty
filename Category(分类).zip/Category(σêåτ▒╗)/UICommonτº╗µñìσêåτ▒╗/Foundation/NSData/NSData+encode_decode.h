//
//  NSData+encode_decode.h
//  UICommon
//
//  Created by shiwei on 15/3/26.
//  Copyright (c) 2015年 YN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (encode_decode)

- (NSData *)AES256EncryptWithKey:(NSString *)key;   //加密

- (NSData *)AES256DecryptWithKey:(NSString *)key;   //解密

@end

void import_NSData_encode_decode();
