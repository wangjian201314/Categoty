//
//  NSString+Extension.m
//  UICommon
//
//  Created by Apple on 15/12/24.
//  Copyright © 2015年 YN. All rights reserved.
//

#import "NSString+Extension.h"
#import "AesEncrypt.h"

@implementation NSString (Extension)
- (BOOL)containsString:(NSString *)aString NS_AVAILABLE(10_10, 8_0){
    if(aString==nil||[aString isKindOfClass:[NSNull class]]||aString.length==0)
    {
        return NO;
    }
    if ([self rangeOfString:aString].location != NSNotFound) {
        return YES;
    }
    return NO;
}
//TODO:guowenchao
- (NSString *)getAESEnCodeStr
{
    NSData * cipher = [self dataUsingEncoding:NSUTF8StringEncoding];
    cipher = [cipher AESEncryptWithKey:@"MasterCom168Cnte" iv:@"MasterCom168Cnte" keySize:128];
    return [cipher base64EncodedString];
}

- (NSString *)getAESDeCodeStr
{
    NSData * cipher = [[NSData alloc] initWithBase64EncodedString:self options:0];
    NSData *decrypt = [cipher AESDecryptWithKey:@"MasterCom168Cnte" iv:@"MasterCom168Cnte" keySize:128];
    return [[NSString alloc] initWithData:decrypt encoding:NSUTF8StringEncoding];
}
//- (NSString *)getEnCodeStrWith:(NSString *)origionCode {
//    NSData * cipher = [origionCode dataUsingEncoding:NSUTF8StringEncoding];
//    cipher = [cipher AESEncryptWithKey:@"MasterCom168Cnte" iv:@"MasterCom168Cnte" keySize:128];
//    return [cipher base64EncodedString];
//}
//
//- (NSString *)getDeCodeStrWith:(NSString *)enCode {
//    NSData * cipher = [[NSData alloc] initWithBase64EncodedString:enCode options:0];
//    NSData *decrypt = [cipher AESDecryptWithKey:@"MasterCom168Cnte" iv:@"MasterCom168Cnte" keySize:128];
//    return [[NSString alloc] initWithData:decrypt encoding:NSUTF8StringEncoding];
//}
@end

void import_NSString_Extension(){}
