//
//  NSString+MD5.h
//  UICommon
//
//  Created by shiwei on 15/3/26.
//  Copyright (c) 2015年 YN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

+(NSString *) md5:(NSString *) input;

+ (NSString*) sha1:(NSString*)input;

@end

void import_NSString_MD5();
