//
//  NSString+Extension.h
//  UICommon
//
//  Created by Apple on 15/12/24.
//  Copyright © 2015年 YN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extension)

- (NSString *)getAESEnCodeStr;

- (NSString *)getAESDeCodeStr;

@end

void import_NSString_Extension();
