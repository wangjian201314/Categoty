//
//  NSObject+PropertyListing.m
//  MTAppPortal
//
//  Created by shiwei on 15/8/3.
//  Copyright (c) 2015年 mastercom. All rights reserved.
//

#import "NSObject+PropertyListing.h"
#import <objc/runtime.h>

@implementation NSObject (PropertyListing)

//所有非空的属性集合
-(NSDictionary *)properties_nonnull{
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    unsigned int outCount, i;
    objc_property_t *properties = class_copyPropertyList([self class], &outCount);
    for (i = 0; i<outCount; i++)
    {
        objc_property_t property = properties[i];
        const char* char_f =property_getName(property);
        NSString *propertyName = [NSString stringWithUTF8String:char_f];
        id propertyValue = [self valueForKey:(NSString *)propertyName];
        if (propertyValue == nil ) {
            continue;
        }
        if (propertyValue) [props setObject:propertyValue forKey:propertyName];
    }
    free(properties);
    return props;
}

/* 获取对象的所有属性 */
- (NSDictionary *)properties_aps
{
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    unsigned int outCount, i;
    objc_property_t *properties = class_copyPropertyList([self class], &outCount);
    for (i = 0; i<outCount; i++)
    {
        objc_property_t property = properties[i];
        const char* char_f =property_getName(property);
        NSString *propertyName = [NSString stringWithUTF8String:char_f];
        id propertyValue = [self valueForKey:(NSString *)propertyName];
        if (propertyValue) [props setObject:propertyValue forKey:propertyName];
    }
    free(properties);
    return props;
}

-(NSArray *)property_names{
    unsigned int outCount;
    objc_property_t *properties = class_copyPropertyList([self class], &outCount);
    
    NSMutableArray* props = [NSMutableArray array];
    for (int i = 0; i< outCount; i++) {
        objc_property_t property = properties[i];
        const char* char_f =property_getName(property);
        NSString *propertyName = [NSString stringWithUTF8String:char_f];
        
        [props addObject:propertyName];
    }
    
    free(properties);
    return props;
}

-(BOOL)isNumberForPropertyName:(NSString *)name{
    Class checkClass = [self class];
    objc_property_t prop = 0;
    while (checkClass && !prop) {
        prop = class_getProperty(checkClass, [name UTF8String]);
        checkClass = class_getSuperclass(checkClass);
    }
    if (!prop) {
        return NO;
    }else{
        unsigned int count = 0;
        objc_property_attribute_t* attris = property_copyAttributeList(prop, &count);
        const char* originType = attris[0].value;
        
        if (strcmp(originType, @encode(int)) == 0 ||
            strcmp(originType, @encode(short)) == 0 ||
            strcmp(originType, @encode(long)) == 0 ||
            strcmp(originType, @encode(long long)) == 0 ||
            strcmp(originType, @encode(unsigned int)) == 0 ||
            strcmp(originType, @encode(unsigned short)) == 0 ||
            strcmp(originType, @encode(unsigned long)) == 0 ||
            strcmp(originType, @encode(unsigned long long)) == 0 ||
            strcmp(originType, @encode(float)) == 0 ||
            strcmp(originType, @encode(double)) == 0 ||
            strcmp(originType, @encode(bool)) == 0 ||
            strcmp(originType, "@\"NSNumber\"") == 0
            ) {
//            free(attris);//add
            return YES;
        }
//        free(attris);//add
        return NO;
    }
}

@end

void import_NSObject_PropertyListing(){}
