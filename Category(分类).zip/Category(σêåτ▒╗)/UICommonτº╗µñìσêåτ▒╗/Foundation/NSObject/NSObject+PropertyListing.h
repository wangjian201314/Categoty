//
//  NSObject+PropertyListing.h
//  MTAppPortal
//
//  Created by shiwei on 15/8/3.
//  Copyright (c) 2015年 mastercom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (PropertyListing)

- (NSDictionary*)properties_nonnull;

- (NSDictionary *)properties_aps;

- (NSArray*)property_names;

    
- (BOOL)isNumberForPropertyName:(NSString*)name;


@end

void import_NSObject_PropertyListing();
