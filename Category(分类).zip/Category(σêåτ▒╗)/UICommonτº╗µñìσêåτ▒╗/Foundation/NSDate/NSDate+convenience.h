//
//  NSDate+convenience.h
//
//  Created by in 't Veen Tjeerd on 4/23/12.
//  Copyright (c) 2012 Vurig Media. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Convenience)

-(NSDate *)offsetMonth:(int)numMonths;
-(NSDate *)offsetDay:(int)numDays;
-(NSDate *)offsetHours:(int)hours;
-(int)numDaysInMonth;
-(int)firstWeekDayInMonth;
-(int)year;
-(int)month;
-(int)day;
/**
 *  获取这个月的第一天在一个星期中的顺序,值为0-6,0为第一天
 *  @param firstWeekDay 指定每个星期第一天从星期几开始,1为星期日,2为星期一,依次类推
 */
-(int)firstWeekDayInMonth:(NSInteger)firstWeekDay;

+(NSDate *)dateStartOfDay:(NSDate *)date;
+(NSDate *)dateStartOfWeek;
+(NSDate *)dateEndOfWeek;

@end

void import_NSDate_convenience();
