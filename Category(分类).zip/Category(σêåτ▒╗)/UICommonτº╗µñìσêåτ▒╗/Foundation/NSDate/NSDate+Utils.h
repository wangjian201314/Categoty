//
//  NSDate+Utils.h
//  NetRecord_BJ
//
//  Created by adt on 13-12-30.
//  Copyright (c) 2013年 MasterCom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Utils)

-(NSInteger)year;
-(NSInteger)month;
-(NSInteger)day;
-(NSInteger)weekDay;
-(NSInteger)weeksIndexInYear;

- (NSUInteger)numberOfDaysInCurrentMonth;
-(int)firstWeekDayInMonth;
@end

void import_NSDate_Utils();
