//
//  UIDevice+Cell.h
//  SystemInfo
//
//  Created by adt on 13-12-2.
//  Copyright (c) 2013年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface MTCellInfo : NSObject
@property NSInteger lac;
@property NSInteger cid;
@property NSInteger band;
@property NSInteger arfcn;
@property NSInteger snr;
@property NSInteger pci;
@property NSInteger rxlev;
@property NSString* network;
@end

@interface UIDevice (Cell)

- (NSString *)udid;
- (NSString *)uuid;
- (NSString *)imei;
- (NSString *)token;
- (NSString *)mt_token;
- (NSString *)imsi;
- (NSString *)phoneNumber;
- (NSString *)mcc;
- (NSString *)mnc;
- (NSString *)networkType;
- (MTCellInfo*)currentCellInfo;
//- (NSString *)networkType2;
//- (NSInteger)lac;
//- (NSInteger)tac;
//- (NSInteger)cid;
- (NSInteger)signalStrength;

- (NSString *)platform;
- (NSString *)platformName;
- (NSString *)version;
- (NSString *)build;

- (int)totalRxBytes;
- (long)wifiRxBytes;
- (long)mobileRxBytes;
- (int)totalTxBytes;
- (long)wifiTxBytes;
- (long)mobileTxBytes;
//- (long)rxBytesWithUid:(NSInteger)uid;

//- (long)totalTxBytes;
//- (long)wifiTxBytes;
//- (long)mobileTxBytes;
//- (long)txBytesWithUid:(NSInteger)uid;

- (NSMutableArray*)neighbourCell;
+ (NSString *)appVersion;
- (NSString *)ipAddress;
- (NSString *)macAddress;
- (NSDictionary *)currentWifiInfo;

@end

void import_UIDevice_Cell();
