//
//  UIView+StackView.h
//  MTAppPortal
//
//  Created by mastercom on 15/11/4.
//  Copyright © 2015年 mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, StackViewType) {
    StackViewTypeHorizontal,
    StackViewTypeVertical,
    StackViewTypeCollection
};

@interface UIView (StackView)

//heights传入NSNumber类型时，表示所有subView大小都是这个
-(void)stackViews:(NSArray*)subViews withHeights:(NSArray*)heights stackType:(StackViewType)type;

-(void)stackViews:(NSArray*)subViews withHeights:(NSArray*)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace;

-(void)stackViews:(NSArray*)subViews withHeights:(NSArray*)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace everySpace:(CGFloat)everySapce;

-(void)stackViews:(NSArray*)subViews withHeights:(NSArray*)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace everySpace:(CGFloat)everySapce sideSapce:(CGFloat)sideSpace;

//新增不确定行数的
-(void)stackViews:(NSArray*)subViews withHeights:(NSArray*)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace everySpaces:(NSArray *)everySapces sideSapce:(CGFloat)sideSpace;

@end

void import_UIView_StackView();
