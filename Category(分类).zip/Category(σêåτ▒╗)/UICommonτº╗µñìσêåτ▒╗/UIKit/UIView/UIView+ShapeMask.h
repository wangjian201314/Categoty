//
//  UIView+ShapeMask.h
//  UICommon
//
//  Created by mastercom on 15/11/23.
//  Copyright © 2015年 YN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ShapeMask)

-(void)maskToRound;

@end

void import_UIView_ShapeMask();
