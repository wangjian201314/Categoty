//
//  UIView+ShapeMask.m
//  UICommon
//
//  Created by mastercom on 15/11/23.
//  Copyright © 2015年 YN. All rights reserved.
//

#import "UIView+ShapeMask.h"

@implementation UIView (ShapeMask)

-(void)maskToRound{
    UIBezierPath* path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.bounds.size.width/2.0, self.bounds.size.height/2.0) radius:MIN(self.bounds.size.width/2.0, self.bounds.size.height/2.0) startAngle:0 endAngle:M_PI*2 clockwise:0];
    
    CAShapeLayer* mask = (CAShapeLayer*)self.layer.mask;
    if (!mask) {
        mask = [[CAShapeLayer alloc]init];
    }
    mask.path = path.CGPath;
    self.layer.mask = mask;
}

@end

void import_UIView_ShapeMask(){}
