//
//  UIView+StackView.m
//  MTAppPortal
//
//  Created by mastercom on 15/11/4.
//  Copyright © 2015年 mastercom. All rights reserved.
//

#import "UIView+StackView.h"

@implementation UIView (StackView)

-(void)stackViews:(NSArray *)subViews withHeights:(NSArray *)heights stackType:(StackViewType)type{
    [self stackViews:subViews withHeights:heights stackType:type firstSpace:0 everySpace:0];
}

-(void)stackViews:(NSArray *)subViews withHeights:(NSArray *)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace{
    [self stackViews:subViews withHeights:heights stackType:type firstSpace:firstSpace everySpace:0];
}

-(void)stackViews:(NSArray *)subViews withHeights:(NSArray *)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace everySpace:(CGFloat)everySapce{
    [self stackViews:subViews withHeights:heights stackType:type firstSpace:firstSpace everySpace:everySapce sideSapce:0];
}

-(void)stackViews:(NSArray *)subViews withHeights:(NSArray *)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace everySpace:(CGFloat)everySapce sideSapce:(CGFloat)sideSpace{
    if (type == StackViewTypeHorizontal) {
        UIView* lastView = nil;
        for (int i = 0; i< subViews.count; i++) {
            
            UIView* view = subViews[i];
            [self addSubview:view];
            view.translatesAutoresizingMaskIntoConstraints = NO;
            
            NSNumber* width = @(0);
            if ([heights isKindOfClass:[NSNumber class]]) {
                width = (NSNumber*)heights;
            }else{
                if (i< heights.count) {
                    width = heights[i];
                }
            }
            
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(sideSpace)-[view]-(sideSpace)-|" options:0 metrics:@{@"sideSpace":@(sideSpace)} views:NSDictionaryOfVariableBindings(view)]];
            
            if (lastView == nil) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(firstSpace)-[view]" options:0 metrics:@{@"firstSpace":@(firstSpace)} views:NSDictionaryOfVariableBindings(view)]];
            }else{
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[lastView]-(everySapce)-[view]" options:0 metrics:@{@"everySapce":@(everySapce)} views:NSDictionaryOfVariableBindings(lastView,view)]];
            }
            //同下
            if (width.floatValue > 1) {
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeWidth) relatedBy:(NSLayoutRelationEqual) toItem:0 attribute:(NSLayoutAttributeNotAnAttribute) multiplier:1.0 constant:width.floatValue]];
            } else if (width.floatValue > 0 && width.floatValue <= 1){
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeWidth) relatedBy:(NSLayoutRelationEqual) toItem:self attribute:(NSLayoutAttributeWidth) multiplier:width.floatValue constant:0]];
            } else if (width.floatValue < 0){
                //小于0的时候，把值认为是高宽比
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:view attribute:(NSLayoutAttributeWidth) multiplier:-width.floatValue constant:0]];
                
            }
            if (i == subViews.count-1) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[view]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)]];
            }
            
            lastView = view;
        }
        
    }else if (type == StackViewTypeVertical){
        
        UIView* lastView = nil;
        for (int i = 0; i< subViews.count; i++) {
            
            UIView* view = subViews[i];
            [self addSubview:view];
            view.translatesAutoresizingMaskIntoConstraints = NO;
            
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(sideSpace)-[view]-(sideSpace)-|" options:0 metrics:@{@"sideSpace":@(sideSpace)} views:NSDictionaryOfVariableBindings(view)]];
            
            NSNumber* width = @(0);
            if ([heights isKindOfClass:[NSNumber class]]) {
                width = (NSNumber*)heights;
            }else{
                if (i< heights.count) {
                    width = heights[i];
                }
            }
            
            if (lastView == nil) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(firstSpace)-[view]" options:0 metrics:@{@"firstSpace":@(firstSpace)} views:NSDictionaryOfVariableBindings(view)]];
            }else{
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[lastView]-(everySapce)-[view]" options:0 metrics:@{@"everySapce":@(everySapce)} views:NSDictionaryOfVariableBindings(lastView,view)]];
            }
            
            //subView的指定宽大于1，则使用这个做宽；如果是小数，则当做比例使用；等于或小于0，就不处理，认为是不设置这个subView的宽
            if (width.floatValue > 1) {
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:0 attribute:(NSLayoutAttributeNotAnAttribute) multiplier:1.0 constant:width.floatValue]];
            }else if (width.floatValue > 0 && width.floatValue <= 1){
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:self attribute:(NSLayoutAttributeHeight) multiplier:width.floatValue constant:0]];
            }else if (width.floatValue < 0){
                //小于0的时候，把值认为是高宽比
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:view attribute:(NSLayoutAttributeWidth) multiplier:-width.floatValue constant:0]];
            }
            if (i == subViews.count-1) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[view]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)]];
            }
            
            lastView = view;
        }
    } else if (type == StackViewTypeCollection) {//为了应对广东的需求 这里这样处理 后期根据传进来的个数分多少个
        
        CGFloat itemW = [UIScreen mainScreen].bounds.size.width / 4;
        for (int i = 0; i< subViews.count; i++) {
            UIView *aView = subViews[i];
            [self addSubview:aView];
            
            CGFloat left = itemW * (i%4);
            CGFloat top  = itemW * (i/4);
            
            aView.translatesAutoresizingMaskIntoConstraints = false;
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-(%lf)-[aView(%lf)]-0-|", left, itemW] options:0 metrics:nil views:NSDictionaryOfVariableBindings(aView)]];
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-(%lf)-[aView(%lf)]-0-|", top, itemW] options:0 metrics:nil views:NSDictionaryOfVariableBindings(aView)]];
        }
    }
}

- (void)stackViews:(NSArray *)subViews withHeights:(NSArray *)heights stackType:(StackViewType)type firstSpace:(CGFloat)firstSpace everySpaces:(NSArray *)everySapces sideSapce:(CGFloat)sideSpace {
    if (type == StackViewTypeHorizontal) {
        
        UIView* lastView = nil;
        for (int i = 0; i< subViews.count; i++) {
            
            UIView* view = subViews[i];
            [self addSubview:view];
            view.translatesAutoresizingMaskIntoConstraints = NO;
            
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(sideSpace)-[view]-(sideSpace)-|" options:0 metrics:@{@"sideSpace":@(sideSpace)} views:NSDictionaryOfVariableBindings(view)]];
            
            NSNumber* width = @(0);
            if ([heights isKindOfClass:[NSNumber class]]) {
                width = (NSNumber*)heights;
            }else{
                if (i< heights.count) {
                    width = heights[i];
                }
            }
            NSNumber *space = everySapces[i];
            
            if (lastView == nil) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(firstSpace)-[view]" options:0 metrics:@{@"firstSpace":@(firstSpace)} views:NSDictionaryOfVariableBindings(view)]];
            }else{
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[lastView]-(everySapce)-[view]" options:0 metrics:@{@"everySapce":space} views:NSDictionaryOfVariableBindings(lastView,view)]];
            }
            //同下
            if (width.floatValue > 1) {
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeWidth) relatedBy:(NSLayoutRelationEqual) toItem:0 attribute:(NSLayoutAttributeNotAnAttribute) multiplier:1.0 constant:width.floatValue]];
            }else if (width.floatValue > 0 && width.floatValue <= 1){
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeWidth) relatedBy:(NSLayoutRelationEqual) toItem:self attribute:(NSLayoutAttributeWidth) multiplier:width.floatValue constant:0]];
            }else if (width.floatValue < 0){
                //小于0的时候，把值认为是高宽比
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:view attribute:(NSLayoutAttributeWidth) multiplier:-width.floatValue constant:0]];
                
            }
            if (i == subViews.count-1) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[view]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)]];
            }
            
            lastView = view;
        }
        
    }else if (type == StackViewTypeVertical){
        
        UIView* lastView = nil;
        for (int i = 0; i< subViews.count; i++) {
            
            UIView* view = subViews[i];
            [self addSubview:view];
            view.translatesAutoresizingMaskIntoConstraints = NO;
            
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(sideSpace)-[view]-(sideSpace)-|" options:0 metrics:@{@"sideSpace":@(sideSpace)} views:NSDictionaryOfVariableBindings(view)]];
            
            NSNumber* width = @(0);
            if ([heights isKindOfClass:[NSNumber class]]) {
                width = (NSNumber*)heights;
            }else{
                if (i< heights.count) {
                    width = heights[i];
                }
            }
            
            NSNumber *space = everySapces[i];
            
            if (lastView == nil) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(firstSpace)-[view]" options:0 metrics:@{@"firstSpace":@(firstSpace)} views:NSDictionaryOfVariableBindings(view)]];
            }else{
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[lastView]-(everySapce)-[view]" options:0 metrics:@{@"everySapce":space} views:NSDictionaryOfVariableBindings(lastView,view)]];
            }
            //subView的指定宽大于1，则使用这个做宽；如果是小数，则当做比例使用；小于0，就不处理，认为是不设置这个subView的宽
            if ([[NSString stringWithFormat:@"%@",width] hasPrefix:@"999"]) {
                CGFloat liveHeight = [[[NSString stringWithFormat:@"%@",width] substringFromIndex:3] floatValue];
                //  999  为新需求设计,为了实现动态高度变化,999以后的数值为初始大小.
                //eg:9991的初始高度为9991-999=1
                [view addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:0 attribute:(NSLayoutAttributeNotAnAttribute) multiplier:1.0 constant:liveHeight]];
            }else if (width.floatValue > 1) {
                NSLayoutConstraint *layoutConstraint = [NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:0 attribute:(NSLayoutAttributeNotAnAttribute) multiplier:1.0 constant:width.floatValue];
                if ([NSStringFromClass([view class]) isEqualToString:@"APScollKeynoteView"]) {
                    layoutConstraint.identifier = @"APScollKeynoteView.height";
                }
                [view addConstraint:layoutConstraint];
            }else if (width.floatValue > 0 && width.floatValue <= 1){
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:self attribute:(NSLayoutAttributeHeight) multiplier:width.floatValue constant:0]];
            }else if (width.floatValue < 0){
                //小于0的时候，把值认为是高宽比
                [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:view attribute:(NSLayoutAttributeWidth) multiplier:-width.floatValue constant:0]];
            }
            if (i == subViews.count-1) {
                [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[view]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)]];
            }
            
            lastView = view;
        }
    }
}

@end

void import_UIView_StackView(){}
